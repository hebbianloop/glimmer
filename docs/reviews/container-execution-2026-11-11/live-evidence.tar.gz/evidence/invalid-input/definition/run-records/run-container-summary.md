---
id: run-container-summary
type: run-record
name: Declared container summary invocation
created: '2026-11-11T00:00:00Z'
modified: '2026-11-11T00:00:00Z'
method: method-container-summary
command: python code/compute.py inputs/values.json out
provenance-mode: deterministic
status: ready
inputs:
- node: dataset-values
  path: inputs/values.json
  role: data
  datalad-commit-sha: 0114e77cc2604912d78723d2d79d74c69750d0e2
  conforms-to: standard-bounded-values
- node: dataset-compute-code
  path: code/compute.py
  role: method-code
  datalad-commit-sha: 841165d7fcb71b82d54a515f9b84b15e7c0fde57
- node: dataset-validator-code
  path: code/check_values.py
  role: validator-code
  datalad-commit-sha: 841165d7fcb71b82d54a515f9b84b15e7c0fde57
- node: dataset-container-entry
  path: code/container_entry.py
  role: trusted-execution-adapter
  datalad-commit-sha: 841165d7fcb71b82d54a515f9b84b15e7c0fde57
- node: dataset-container-registration
  path: .datalad/config
  role: trusted-container-registration
  datalad-commit-sha: 841165d7fcb71b82d54a515f9b84b15e7c0fde57
- node: dataset-expected-baseline
  path: expected/summary.json
  role: authored-comparison-baseline
  datalad-commit-sha: 841165d7fcb71b82d54a515f9b84b15e7c0fde57
outputs:
- node: derivative-raw-summary
  output-path: out/raw.json
  tier: byte-identical
  expected-hash: sha256:c15d94c6e981ad26353b218936cc0a10aa4abe7196cee0f8c52d858f6d7af9a5
- node: derivative-numeric-summary
  output-path: out/numeric.json
  tier: numeric-tolerance
  expected-values:
    count: 4
    mean: 5.0
    sum: 20.0
container-image: python-fixture
container-digest: sha256:e2ab69a46c792c843015e9e17888fe8b062af8a482cb9bee14da0093a8a89854
reproduction-tolerance:
  default:
    abs: 0.0
    rel: 0.0
edges:
- type: reruns
  target: method-container-summary
- type: addresses-concept
  target: concept-container-replay
- type: requires-standard
  target: standard-bounded-values
- type: consumes
  target: dataset-values
- type: consumes
  target: dataset-compute-code
- type: consumes
  target: dataset-validator-code
- type: consumes
  target: dataset-container-entry
- type: consumes
  target: dataset-container-registration
- type: consumes
  target: dataset-expected-baseline
- type: regenerates
  target: derivative-raw-summary
- type: regenerates
  target: derivative-numeric-summary
provenance-hash: sha256:b51bbf97d64670a5f0328275ea51949b3dbe1561c12e5f065378220d73af88d9
---

Synthetic container qualification; not a scientific finding.
