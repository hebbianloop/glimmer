---
id: dataset-values
type: dataset
name: Data
created: '2026-11-11T00:00:00Z'
modified: '2026-11-11T00:00:00Z'
datalad-relative-path: inputs/values.json
datalad-commit-sha: 647fb01d54378528d706c0851c0cb46cd53b2a63
data-provenance: Committed synthetic fixture source; no participant data
edges:
- type: conforms-to
  target: standard-bounded-values
provenance-hash: sha256:b51bbf97d64670a5f0328275ea51949b3dbe1561c12e5f065378220d73af88d9
---

Synthetic container qualification; not a scientific finding.
