---
id: dataset-values
type: dataset
name: Data
created: '2026-11-11T00:00:00Z'
modified: '2026-11-11T00:00:00Z'
datalad-relative-path: inputs/values.json
datalad-commit-sha: 0114e77cc2604912d78723d2d79d74c69750d0e2
data-provenance: Committed synthetic fixture source; no participant data
edges:
- type: conforms-to
  target: standard-bounded-values
provenance-hash: sha256:b51bbf97d64670a5f0328275ea51949b3dbe1561c12e5f065378220d73af88d9
---

Synthetic container qualification; not a scientific finding.
