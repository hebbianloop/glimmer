---
id: method-container-summary
type: method
name: Summarize four synthetic values
created: '2026-11-11T00:00:00Z'
modified: '2026-11-11T00:00:00Z'
tool: Python standard library
version: fixture-1
parameters:
  sum: math.fsum
  mean: sum / count
workflow-definition-sha: sha256:8d952172bfe694362a7fca4db9b64d97698b8dbe1bf1c69f81351af815e1675b
edges: []
provenance-hash: sha256:b51bbf97d64670a5f0328275ea51949b3dbe1561c12e5f065378220d73af88d9
---

Synthetic container qualification; not a scientific finding.
