---
id: derivative-numeric-summary
type: derivative
name: Numeric summary output
created: '2026-11-11T00:00:00Z'
modified: '2026-11-11T00:00:00Z'
provenance-mode: deterministic
output-path: out/numeric.json
output-format: json
edges:
- type: produced-by
  target: method-container-summary
- type: derives-from
  target: dataset-values
provenance-hash: sha256:b51bbf97d64670a5f0328275ea51949b3dbe1561c12e5f065378220d73af88d9
---

Synthetic container qualification; not a scientific finding.
