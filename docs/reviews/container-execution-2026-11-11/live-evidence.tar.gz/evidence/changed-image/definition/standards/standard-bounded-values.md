---
id: standard-bounded-values
type: standard
name: Bounded numeric-list fixture format
created: '2026-11-11T00:00:00Z'
modified: '2026-11-11T00:00:00Z'
standard-class: spec
version: '1'
validator:
  kind: external
  command: python code/check_values.py {path}
edges: []
provenance-hash: sha256:b51bbf97d64670a5f0328275ea51949b3dbe1561c12e5f065378220d73af88d9
---

Synthetic container qualification; not a scientific finding.
