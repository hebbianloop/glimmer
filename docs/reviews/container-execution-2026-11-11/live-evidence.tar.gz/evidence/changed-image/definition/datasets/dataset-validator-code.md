---
id: dataset-validator-code
type: dataset
name: Validator code
created: '2026-11-11T00:00:00Z'
modified: '2026-11-11T00:00:00Z'
datalad-relative-path: code/check_values.py
datalad-commit-sha: 841165d7fcb71b82d54a515f9b84b15e7c0fde57
data-provenance: Committed synthetic fixture source; no participant data
edges: []
provenance-hash: sha256:b51bbf97d64670a5f0328275ea51949b3dbe1561c12e5f065378220d73af88d9
---

Synthetic container qualification; not a scientific finding.
